from .prepro import *
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.neural_network import MLPRegressor
from sklearn.linear_model import Lasso
from sklearn.linear_model import LinearRegression
from django.shortcuts import render
from sklearn.metrics import mean_absolute_error,mean_squared_error,r2_score
      

class MTrain:
    
    def dtree():
        de = DecisionTreeRegressor()
        de = de.fit(x_train,y_train)
        de_pred = de.predict(x_test)
        r2_de = r2_score(de_pred,y_test)
        mb_da = mean_absolute_error(de_pred,y_test)
        me_da = mean_squared_error(de_pred,y_test)
        r2_dd = r2_de-r2_de*2
        de_sc = [r2_dd,mb_da,me_da]
        return de_sc
        
    def randForest():
        re = RandomForestRegressor()
        re.fit(x_train,y_train)
        re_pred = re.predict(x_test)
        r2_ra = r2_score(y_test,re_pred)
        mb_ra = mean_absolute_error(y_test,re_pred)
        ms_ra = mean_squared_error(y_test,re_pred)
        r2_rr = r2_ra-r2_ra*2
        ra_sc = [r2_rr,mb_ra,ms_ra]
        return ra_sc
        
    def logireg():
        lr = LinearRegression()
        lr.fit(x_train,y_train)
        lr_pred = lr.predict(x_test)
        r2_lr = r2_score(y_test,lr_pred)
        mb_lr = mean_absolute_error(y_test,lr_pred)
        ms_lr = mean_squared_error(y_test,lr_pred)
        r2_ll = r2_lr-r2_lr*2
        lr_sc = [r2_ll,mb_lr,ms_lr]
        return lr_sc
    
    def lasso():
        lr = Lasso()
        lr.fit(x_train,y_train)
        lr_pred = lr.predict(x_test)
        r2_lr = r2_score(y_test,lr_pred)
        mb_lr = mean_absolute_error(y_test,lr_pred)
        ms_lr = mean_squared_error(y_test,lr_pred)
        r2_ll = r2_lr-r2_lr*2
        lr_sc = [r2_ll,mb_lr,ms_lr]
        return lr_sc
    
    def mlpp():
        lr = MLPRegressor()
        lr.fit(x_train,y_train)
        lr_pred = lr.predict(x_test)
        r2_lr = r2_score(y_test,lr_pred)
        mb_lr = mean_absolute_error(y_test,lr_pred)
        ms_lr = mean_squared_error(y_test,lr_pred)
        r2_ll = r2_lr-r2_lr*2
        lr_sc = [r2_ll,mb_lr,ms_lr]
        return lr_sc
    