from django.shortcuts import render
from .data import *
from .mtrain import *
import pickle

class Userhome():
    def uhoma(req):
        return render(req,'uhome.html')
    
    def view(req):
        dff = pd.read_csv('flightapp/Dataset/flight_data1.csv')
        da = dff.to_html()
        return render(req,'view.html',{'da':da})
    
    def train(req):
        if req.method == 'POST':
            module = req.POST['algo']
            if module == '0':
                return render(req,'train.html',{'msg':'invalid'})
            elif module == '1':
                Det = MTrain.dtree()
                print(Det)
                return render(req,'train.html',{'Det':Det,'msg':'123'})
            elif module == '2':
                Det = MTrain.randForest()
                print(Det)
                return render(req,'train.html',{'Det':Det,'msg':'234'})
            elif module == '3':
                Det = MTrain.logireg()
                print(Det)
                return render(req,'train.html',{'Det':Det,'msg':'345'})
            elif module == '4':
                Det = MTrain.lasso()
                print(Det)
                return render(req,'train.html',{'Det':Det,'msg':'346'})
            elif module == '5':
                Det = MTrain.mlpp()
                print(Det)
                return render(req,'train.html',{'Det':Det,'msg':'347'})
        return render(req,'train.html')
    
    
    def predict(req):

        if req.method == 'POST':
        

            f1=float(req.POST['Airline'])
            f2=float(req.POST['Source'])
            f3=float(req.POST['Destination'])
            f4=float(req.POST['Total Stops'])
            f5=float(req.POST['Additional Info'])
            f6=float(req.POST['Cabin Class'])
            f7=float(req.POST['In-flight Wi-Fi'])
            f8=float(req.POST['Baggage Info'])
            f9=float(req.POST['Seat Comfort'])
            f10=float(req.POST['On-time History'])
            f11=float(req.POST['Competition'])
            f12=float(req.POST['Peak Season'])


            PRED = [[f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,f11,f12]]
            with open('Flightapp/Module/DT.pkl','rb') as f:
                DT = pickle.load(f)
            result = DT.predict(PRED)
            print(result)
            msg = 'The Predicted price'+' '+str(result)
            return render(req,'predict.html',{'msg':msg})
        return render(req,'predict.html')


    if __name__ == '__main__':
        uhoma()
        view()
        train()