// script.js

// // Function to handle the click event of the Login button
// document.getElementById('login').addEventListener('click', function () {
//     // You can add your login functionality here
//     alert('Login clicked!'); // For demonstration purposes
// });
