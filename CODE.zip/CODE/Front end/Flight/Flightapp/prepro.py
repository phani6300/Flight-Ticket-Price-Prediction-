from .data import *
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split

class Pre:
    def prr():
        global x_train,x_test,y_train,y_test
        df['Baggage Info'].replace({'14 kg allowance': 14, '18 kg allowance': 18, '16 kg allowance': 16, '28 kg allowance': 28, '19 kg allowance': 19,
        '26 kg allowance': 26, '20 kg allowance': 20, '27 kg allowance': 27, '24 kg allowance': 24, '23 kg allowance': 23, '22 kg allowance': 22, '21 kg allowance': 21,
        '17 kg allowance': 17, '11 kg allowance': 11, '12 kg allowance': 12, '13 kg allowance': 13,  '15 kg allowance': 15,  '10 kg allowance': 10,
        '29 kg allowance': 29, '30 kg allowance': 30, '25 kg allowance': 25}, inplace = True)
        df.drop(['Departure Date', 'Arrival Date', 'Duration'], axis=1, inplace=True)
        col = df[['Airline','Source','Destination','Additional Info','Cabin Class','In-flight Wi-Fi','Baggage Info','Competition','Peak Season']]
        le = LabelEncoder()
        for i in col:
            df[i] = le.fit_transform(df[i])
        X = df.drop(['Price'],axis=1)
        y = df['Price']
        x_train,x_test,y_train,y_test = train_test_split(X,y, test_size=0.3,random_state=42)
    prr()
