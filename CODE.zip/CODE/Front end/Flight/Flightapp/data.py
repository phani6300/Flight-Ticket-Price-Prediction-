import pandas as pd

class DataRead:
    global df
    def read(data):
        global df
        df = pd.read_csv(data)
    read('flightapp/Dataset/flight_data1.csv')