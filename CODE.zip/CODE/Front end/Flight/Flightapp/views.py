from django.shortcuts import render
from django.contrib.auth.models import User

# Create your views here.

def index(req):
    return render(req,'index.html')


def about(req):
    return render(req,'about.html')


def login(req):
    if req.method == 'POST':
        uemail = req.POST['uemail']
        upass = req.POST['upass']
        user =  User.objects.filter(email = uemail,password = upass).exists()
        if user:
           return render(req,'uhome.html')
    return render(req,'login.html')

def register(req):
    if req.method == 'POST':
        uname = req.POST['uname']
        uemail = req.POST['uemail']
        upass = req.POST['upass']
        cpass = req.POST['cpass']
        print('_________________________________________')
        if upass == cpass:
            User.objects.create(username = uname,email = uemail,password = upass)
            return render(req,'login.html')
    return render(req,'register.html')